package com.company;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.awt.print.PrinterException;
import java.sql.*;

public class View extends JFrame{
    private JTable table1;
    private JPanel panel1;
    private JButton EXITButton;
    private JComboBox Class;
    private JComboBox sort;
    private JLabel VIEWButton;
    private JButton PRINTButton;
    private JPanel fat;
    private JTabbedPane far;
    private JScrollPane sor;
    private JTextField search;
    private JLabel a;
    private JButton addStudentButton;
    private JLabel dashboard;
    private JLabel accounts;
    private JButton VIEWButtons;
    private JFrame frame;
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    UIAdditions additions = new UIAdditions();
    databases dbs= new databases();
    filter f= new filter();

    DefaultTableModel model = new DefaultTableModel(
            null,
            new String[]{"Reg Number", "Name", "Surname", "Gender", "BirthDate", "Class", "Admission Date", "Address",
                    "Home", "Phone Number", "Code Number", "Med Problems", "Actions"}
    ){
        @Override
        public boolean isCellEditable(int row, int column) {
            // Set all cells non-editable except the last one which contains buttons
            return column == getColumnCount() - 1;
        }
    };

    public View() {
        createTable();
        dbs.getResult(table1, a);
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                View.this.frame.setVisible(false);
                HomePage j=new HomePage();
//                j.ted();
            }
        });

        addStudentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                View.this.frame.setVisible(true);
                Reg j=new Reg();
                j.ted();
            }
        });

        //go to students page
        VIEWButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                View.this.frame.setVisible(false);
                View j=new View();
                j.ted();
            }
        });

        //go to accounts page
        accounts.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                View.this.frame.setVisible(false);
                Accounts j=new Accounts();
                j.ted();
            }
        });

        //go to accounts page
        dashboard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                View.this.frame.setVisible(false);
                HomePage j=new HomePage();
            }
        });

//        print all results in the table
        PRINTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    table1.print();
                } catch (PrinterException ex) {
                    ex.printStackTrace();
                }
            }
        });

//        display all students belonging to certain class
        Class.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                dbs.getResults(model, table1, Class, a);
            }
        });

//        display by search
        search.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String searchValue= search.getText();
                dbs.searchResult(model, table1, a, searchValue);
            }
        });

//        sort items in table
        sort.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    // Get the selected item
                    String selectedOption = (String) sort.getSelectedItem();

                    // If selected item is "Option 2", execute some code
                    if ("Admission".equals(selectedOption)) {
                        // Execute code when Option 2 is selected
                        f.sortData(model);
                    }else if ("Class (Desc)".equals(selectedOption)) {
                        // Execute code when Option 2 is selected
                        f.sortByClass(model);
                    }else if ("Class (Asc)".equals(selectedOption)) {
                        // Execute code when Option 2 is selected
                        f.sortByClass1(model);
                    }
                }
            }
        });


        Border emptyBorder = BorderFactory.createEmptyBorder();
        Class.setBorder(emptyBorder);
        sort.setBorder(emptyBorder);
        additions.setPlaceholder(search, "Search Here");
        addStudentButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        EXITButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        VIEWButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        dashboard.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        accounts.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;

        frame = new JFrame("View Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(screenWidth, screenHeight));
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize the frame
        frame.setResizable(true);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);

    }
    private void createTable(){
        table1.setModel(model);
    }


    public static void ted() {
        new View().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }

}
