package com.company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.time.LocalDate;

public class databases {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    int currentYear = LocalDate.now().getYear();

    public void getResults(DefaultTableModel model, JTable table1, JComboBox Class, JLabel a){
        model.setRowCount(0);
        try {
            String query = "Select * from registration WHERE class=?";
            con = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
            pst = con.prepareStatement(query);
            pst.setString(1,Class.getSelectedItem().toString());
            rs = pst.executeQuery();

            while (rs.next()) {
                String S = rs.getString("Student_ID");;
                String N = rs.getString("Name");
                String SU = rs.getString("Surname");;
                String Sex = rs.getString("Sex");
                String BD = rs.getString("BirthDate");
                String C=rs.getString("class");
                String A=rs.getString("admission");
                String ad=rs.getString("adress");
                String H= rs.getString("Home");
                String P= rs.getString("Phone");
                String CO= rs.getString("Code");
                String M= rs.getString("Medical");

                String[] tbData = {S, N, SU, Sex, BD,C,A,ad,H,P,CO,M};
                model = (DefaultTableModel) table1.getModel();
                model.addRow(tbData);
                int b=table1.getRowCount();
                a.setText("Showing all "+String.valueOf(b)+" Students");
            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void getStudentCount(JLabel a, String cat){
        int rowCount = 0;
        try {
            String query = "Select COUNT(*) AS myCount from registration where Category = ?";
            con = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
            pst = con.prepareStatement(query);
            pst.setString(1, cat);
            rs = pst.executeQuery();

            if (rs.next()) {
                rowCount = rs.getInt("myCount");
                a.setText(String.valueOf(rowCount));
            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void getStudentCount1(JLabel a){
        try {
            String query = "Select COUNT(*) from registration";
            con = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            if (rs.next()) {
                int rowCount = rs.getInt(1);
                a.setText(String.valueOf(rowCount));
            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public int getStats(String date, String Class){
        int rowCount = 0;
        try {
            String query = "Select COUNT(*) AS myCount from registration where class = ? AND YEAR(STR_TO_DATE(admission, '%m/%d/%Y')) = ?";
            con = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
            pst = con.prepareStatement(query);
            pst.setString(1, Class);
            pst.setString(2, date);
            rs = pst.executeQuery();

            if (rs.next()) {
                rowCount = rs.getInt("myCount");
            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }

        return  rowCount;
    }

    public void searchResult(DefaultTableModel model, JTable table1, JLabel a, String inputName){
        model.setRowCount(0);
        try {
            String query = "Select * from registration WHERE name LIKE ? OR surname LIKE ?";
            con = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
            pst = con.prepareStatement(query);
            pst.setString(1, "%" + inputName + "%");  // for firstname
            pst.setString(2, "%" + inputName + "%");  // for lastname
            rs = pst.executeQuery();

            while (rs.next()) {
                String S = rs.getString("Student_ID");;
                String N = rs.getString("Name");
                String SU = rs.getString("Surname");;
                String Sex = rs.getString("Sex");
                String BD = rs.getString("BirthDate");
                String C=rs.getString("class");
                String A=rs.getString("admission");
                String ad=rs.getString("adress");
                String H= rs.getString("Home");
                String P= rs.getString("Phone");
                String CO= rs.getString("Code");
                String M= rs.getString("Medical");

                String[] tbData = {S, N, SU, Sex, BD,C,A,ad,H,P,CO,M};
                DefaultTableModel tb1Model = (DefaultTableModel) table1.getModel();
                tb1Model.addRow(tbData);
                int b=table1.getRowCount();
                a.setText("Showing all "+String.valueOf(b)+" Students");
            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void getResult(JTable table1, JLabel a){
        try {
            String query = "Select * from registration";
            con = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
                String S = rs.getString("Student_ID");;
                String N = rs.getString("Name");
                String SU = rs.getString("Surname");;
                String Sex = rs.getString("Sex");
                String BD = rs.getString("BirthDate");
                String C=rs.getString("class");
                String A=rs.getString("admission");
                String ad=rs.getString("adress");
                String H= rs.getString("Home");
                String P= rs.getString("Phone");
                String CO= rs.getString("Code");
                String M= rs.getString("Medical");
                String id = rs.getString("id");

                String[] tbData = {S, N, SU, Sex, BD, C, A, ad, H, P, CO, M};
                CustomButton button = new CustomButton("Edit", id);
                button.setPreferredSize(new Dimension(60, 20));
                // Add action listener to the button
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        CustomButton sourceButton = (CustomButton) e.getSource();
                        String studentID = sourceButton.getID();
                        Search j = new Search(studentID);
                        j.ted();
                    }
                });


                String[] rowData = new String[tbData.length + 1];
                System.arraycopy(tbData, 0, rowData, 0, tbData.length);
                rowData[tbData.length] = "";
                DefaultTableModel tb1Model = (DefaultTableModel) table1.getModel();
                tb1Model.addRow(rowData);
                table1.getColumn("Actions").setCellRenderer(new ButtonRenderer());
                table1.getColumn("Actions").setCellEditor(new ButtonEditor(button));
                int b=table1.getRowCount();
                a.setText("Showing all "+String.valueOf(b)+" Students");
            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    static class ButtonRenderer implements TableCellRenderer {
        private JButton button;

        public ButtonRenderer() {
            button = createCustomButton("Edit", Color.WHITE, new Dimension(60, 20));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return button;
        }
    }

    static class ButtonEditor extends DefaultCellEditor {
        private JButton button;

        public ButtonEditor(JButton button) {
            super(new JTextField());
            this.button = button;
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            return button.getText();
        }

        @Override
        public boolean stopCellEditing() {
            fireEditingStopped();
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }

    private static JButton createCustomButton(String text, Color color, Dimension size) {
        JButton button = new JButton(text);
        button.setPreferredSize(size);
        button.setBackground(color);
        button.setForeground(Color.BLACK);
        return button;
    }

    private ActionListener createActionListener(String id) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String studentID = e.getActionCommand();
                Search j = new Search(studentID);
                j.ted();
            }
        };
    }

    class CustomButton extends JButton {
        private String id;

        public CustomButton(String text, String id) {
            super(text);
            this.id = id;
        }

        public String getID() {
            return id;
        }
    }
}
