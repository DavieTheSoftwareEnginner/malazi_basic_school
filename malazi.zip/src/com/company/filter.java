package com.company;

import javax.swing.table.DefaultTableModel;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Vector;

public class filter {

    public void sortData(DefaultTableModel model) {
        // Sort dates
        Collections.sort(model.getDataVector(), new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                    Date date1 = dateFormat.parse((String) ((Vector<?>) o1).get(6));
                    Date date2 = dateFormat.parse((String) ((Vector<?>) o2).get(6));
                    return date2.compareTo(date1);
                }  catch (ParseException ex) {
                    ex.printStackTrace();
                    return 0;
                }
            }
        });

        // Refresh table
        model.fireTableDataChanged();
    }

    public void sortByClass(DefaultTableModel model) {
        // Sort dates
        Collections.sort(model.getDataVector(), new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
                Integer one = Integer.parseInt((String) ((Vector<?>) o1).get(5));
                Integer two = Integer.parseInt((String) ((Vector<?>) o2).get(5));
                return two.compareTo(one);
            }
        });

        // Refresh table
        model.fireTableDataChanged();
    }

    public void sortByClass1(DefaultTableModel model) {
        // Sort dates
        Collections.sort(model.getDataVector(), new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
                Integer one = Integer.parseInt((String) ((Vector<?>) o1).get(5));
                Integer two = Integer.parseInt((String) ((Vector<?>) o2).get(5));
                return one.compareTo(two);
            }
        });

        // Refresh table
        model.fireTableDataChanged();
    }
}
