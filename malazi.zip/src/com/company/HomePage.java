package com.company;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Label;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class HomePage extends JFrame{
    private JPanel panel1;
    private JPanel box1;
    private JPanel box2;
    private JPanel box3;
    private JPanel box4;
    private JPanel graph;
    private JButton REGISTERButton;
    private JButton EDITButton;
    private JButton EXITButton;
    private JLabel VIEWButton;
    private JLabel dashboard;
    private JLabel accounts;
    private JLabel a;
    private JLabel b;
    private JLabel c;
    private JButton SEARCHANDDELETEButton;
    private JFrame frame;

    UIAdditions additions = new UIAdditions();
    databases db = new databases();

    public HomePage() {
        this.dispose();
        String cat = "Boarder";
        String cat1 = "Commuter";
        db.getStudentCount1(a);
        db.getStudentCount(b, cat);
        db.getStudentCount(c, cat1);
//        REGISTERButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                HomePage.this.frame.setVisible(false);
//                Reg j= new Reg();
//                j.ted();
//            }
//        });
//        VIEWButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                HomePage.this.frame.setVisible(false);
//                View j=new View();
//                j.ted();
//            }
//        });
//        EDITButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                HomePage.this.frame.setVisible(false);
//                Accounts j=new Accounts();
//                j.ted();
//            }
//        });
//        SEARCHANDDELETEButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                HomePage.this.frame.setVisible(false);
//                Search j= new Search();
//                j.ted();
//            }
//        });
//        EXITButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                HomePage.this.frame.setVisible(false);
//                Home j=new Home();
//                j.ted();
//            }
//        });

//        go to students page
        VIEWButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                HomePage.this.frame.setVisible(false);
                View j=new View();
                j.ted();
            }
        });

//        go to accounts page
        accounts.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                HomePage.this.frame.setVisible(false);
                Accounts j=new Accounts();
                j.ted();
            }
        });

        //        go to accounts page
        dashboard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                HomePage.this.frame.setVisible(false);
                HomePage j=new HomePage();
            }
        });

        SwingUtilities.invokeLater(() -> {
            CategoryDataset dataset = BarChartCreator.createDataset();

            // Create chart
            JFreeChart chart = BarChartCreator.createChart(dataset);

            // Create Panel
            JPanel chartPanel = BarChartCreator.createChartPanel(chart);

            graph.add(chartPanel, BorderLayout.CENTER);;
//
//            // Initialize JavaFX within the JFXPanel
//            Platform.runLater(() -> initFX(jfxPanel));

            additions.setRoundedBorder1(box1,5, Color.lightGray);
            additions.setRoundedBorder1(box2,5, Color.lightGray);
            additions.setRoundedBorder1(box3,5, Color.lightGray);
            additions.setRoundedBorder1(box4,5, Color.lightGray);
            VIEWButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            dashboard.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            accounts.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            int screenWidth = screenSize.width;
            int screenHeight = screenSize.height;

            frame = new JFrame("Malazi Basic School Page");
            frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
            frame.setPreferredSize(new Dimension(screenWidth, screenHeight));
            frame.setResizable(true);

            frame.add(panel1);

            frame.pack();
            frame.setVisible(true);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }


    public static void ted() {
        new HomePage();
    }

    public static void main(String[] args) {
        ted();
    }

}
