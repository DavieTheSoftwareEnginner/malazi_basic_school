package com.company;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;


public class Reg extends JFrame {
    private JPanel panel1;
    private JTextField number;
    private JPanel Jadate;
    private JComboBox Class;
    private JTextField reg;
    private JTextField code;
    private JTextField mp;
    private JButton ADDButton;
    private JButton EXITButton;
    private JTextField surname;
    private JTextField adress;
    private JComboBox home;
    private JTextField name;
    private JRadioButton female;
    private JComboBox Gender;
    private JComboBox cat;
    private JPanel Jdate;
    private JFrame frame;
    
    JDateChooser dateChooser=new JDateChooser();
    JDateChooser smile=new JDateChooser();
    UIAdditions add = new UIAdditions();

    public Reg() {
        smile.setDateFormatString("dd/MM/yyyy");
        dateChooser.setDateFormatString("dd/MM/yyyy");
        Jadate.add(smile);
        Jdate.add(dateChooser);
        ADDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               if (reg.getText().isEmpty() || name.getText().isEmpty() || surname.getText().isEmpty()  || Class.getSelectedItem().toString().isEmpty() ||
                    adress.getText().isEmpty() || home.getSelectedItem().toString().isEmpty() || number.getText().isEmpty() || code.getText().isEmpty() || mp.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields are required");
                } else {
                    try {
                        String sql = "Select * from registration where student_id=? or name=? and surname=?";
                        Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst1 = con1.prepareStatement(sql);
                        pst1.setString(1, reg.getText());
                        pst1.setString(2, name.getText());
                        pst1.setString(3, surname.getText());
                        ResultSet rs = pst1.executeQuery();
                        if(rs.next()){
                            JOptionPane.showMessageDialog(null,"Registration Number or Student Name Already Exist");
                        }
                        else{
                            SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy");
                            String dt=simpleDateFormat.format(dateChooser.getDate());
                            String adt=simpleDateFormat.format(smile.getDate());
                            String query = "Insert into registration(category,student_id,name,surname,sex,BirthDate,class,admission,adress,Home,phone,code, Medical)" +
                                    "Values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            PreparedStatement pst = con.prepareStatement(query);
                            pst.setString(1,cat.getSelectedItem().toString());
                            pst.setString(2, reg.getText());
                            pst.setString(3, name.getText());
                            pst.setString(4, surname.getText());
                            pst.setString(5, Gender.getSelectedItem().toString());
                            pst.setString(6, dt);
                            pst.setString(7, Class.getSelectedItem().toString());
                            pst.setString(8, adt);
                            pst.setString(9, adress.getText());
                            pst.setString(10, home.getSelectedItem().toString());
                            pst.setString(11, number.getText());
                            pst.setString(12, code.getText());
                            pst.setString(13, mp.getText());
                            pst.execute();
                            JOptionPane.showMessageDialog(null, "Registration Successful");
                        }
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Reg.this.frame.setVisible(false);
            }
        });

        Border border = BorderFactory.createLineBorder(Color.decode("#D1D5DB"), 2); // 2 is the border thickness
        Border border1 = BorderFactory.createLineBorder(Color.WHITE, 2);
        JTextField[] textField = {number, reg, code, mp, adress, surname, name};
        JPanel[] panels = {Jdate, Jadate};
        JDateChooser[] choosers = {smile, dateChooser};
        JComboBox[] boxes = {Class, home, Gender, cat};


        for (JTextField panel : textField) {
            panel.setBorder(border);
            add.setRoundedBorder2(panel, 5, Color.decode("#D1D5DB"));
        }

        for (JPanel panel : panels) {
//            panel.setBorder(border);
           add.setRoundedBorder1(panel, 5, Color.decode("#D1D5DB"));
        }

        for (JDateChooser panel : choosers) {
            panel.setBorder(border1);
        }

        for (JComboBox panel : boxes) {
            add.setRoundedBorder3(panel, 5, Color.decode("#D1D5DB"));
        }

        add.setRoundedBorder1(panel1, 10, Color.decode("#D1D5DB"));

        panel1.setPreferredSize(new Dimension(600, 720));
        frame = new JFrame("Registration Page");
//        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
//        frame.setPreferredSize(new Dimension(600, 720));
        frame.setUndecorated(true);
        frame.setResizable(false);
        frame.add(panel1);
        frame.setUndecorated(true);
        frame.pack();
        frame.setLocationRelativeTo(null);

        Class.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (cat.getSelectedItem().toString().equals("Boarder")) {
                    try {
                        String query = "Select * from registration where class=? and Category=?";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setString(1, Class.getSelectedItem().toString());
                        pst.setString(2, cat.getSelectedItem().toString());
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            String query1 = "Select * from Registration where Student_ID IN(SELECT Max(student_id) from Registration where Class=? and Category=?)";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
                            PreparedStatement st = con1.prepareStatement(query1);
                            st.setString(1,Class.getSelectedItem().toString());
                            st.setString(2,cat.getSelectedItem().toString());
                            ResultSet rs1 = st.executeQuery();
                            if (rs1.next()) {
                                int r = rs1.getInt("Student_id");
                                int d = r + 1;
                                String f = String.valueOf(d);
                                reg.setText(f);
                            }
                        } else {
                            GregorianCalendar dat = new GregorianCalendar();
                            int year = dat.get(Calendar.YEAR);
                            String g = Class.getSelectedItem().toString();
                            String j = g + "1" + year + "001";
                            reg.setText(j);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }else{
                    try {
                        String query = "Select * from registration where class=? and Category=?";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david?useSSL=false", "root", "");
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setString(1, Class.getSelectedItem().toString());
                        pst.setString(2, cat.getSelectedItem().toString());
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            String query1 = "Select * from Registration where Student_ID IN(SELECT Max(student_id) from Registration where Class=? and Category=?)";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            PreparedStatement st = con1.prepareStatement(query1);
                            st.setString(1,Class.getSelectedItem().toString());
                            st.setString(2,cat.getSelectedItem().toString());
                            ResultSet rs1 = st.executeQuery();
                            if (rs1.next()) {
                                int r = rs1.getInt("Student_id");
                                int d = r + 1;
                                String f = String.valueOf(d);
                                reg.setText(f);
                            }
                        } else {
                            GregorianCalendar dat = new GregorianCalendar();
                            int year = dat.get(Calendar.YEAR);
                            String g = Class.getSelectedItem().toString();
                            String j = g + "2" + year + "001";
                            reg.setText(j);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
    }

    public static void ted() {
        new Reg().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }

}
