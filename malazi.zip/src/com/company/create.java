package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class create extends JFrame {
    private JPanel panel1;
    private JTextField UserName;
    private JPasswordField Password;
    private JTextField confirm;
    private JButton SIngUpButton;
    private JFrame frame;
    private JButton EXITButton;
    private Label password;

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs= null;
    UIAdditions additions= new UIAdditions();

    public create() {
        SIngUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (UserName.getText().isEmpty()||confirm.getText().isEmpty()||Password.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields are required");
                }
                else {
                    try {
                        String change = "SELECT * from Login";
                        con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        pst = con.prepareStatement(change);
                        rs = pst.executeQuery();

                        if (rs.next()) {
                            JOptionPane.showMessageDialog(null, "Another Account arleady exits");
                        }
                        else {
                            String query = "INSERT INTO login (UserName, Password) VALUES (?,?)";
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            PreparedStatement pst = con.prepareStatement(query);
                            pst.setString(1, UserName.getText());
                            pst.setString(3, Password.getText());
                            pst.setString(2, confirm.getText());
                            pst.execute();
                            JOptionPane.showMessageDialog(null, "You are registered");
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                create.this.frame.setVisible(false);
                Login j=new Login();
                j.ted();
            }
        });
        Password.setBorder(null);
        UserName.setBorder(null);
        confirm.setBorder(null);
        additions.setRoundedBorder(EXITButton, 40, Color.WHITE);
        EXITButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        SIngUpButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        additions.setPlaceholder(UserName, "Username");
        additions.setPlaceholder(Password, "password");
        additions.setPlaceholder(confirm, "confirm password");
        frame = new JFrame("Create Account page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(840, 500));
        frame.setResizable(true);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
    }
    public static void ted(){
        new create().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }

}