package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Change extends JFrame{
    private JPanel panel1;
    private JTextField username;
    private JTextField password;
    private JTextField pass;
    private JTextField pass1;
    private JButton CHANGEButton;
    private JButton EXITButton;
    private JFrame frame;
    Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    public Change() {
        CHANGEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    String sql="Select * from login where username=? and password=?";
                    con= DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst=con.prepareStatement(sql);
                    pst.setString(1,username.getText());
                    pst.setString(2,password.getText());
                    rs= pst.executeQuery();
                    if(rs.next()){
                        if(pass.getText().equals(pass1.getText())){
                            String query="Update login set password=? where username=? and password=?";
                            con=DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            pst=con.prepareStatement(query);
                            pst.setString(1,pass.getText());
                            pst.setString(2,username.getText());
                            pst.setString(3,password.getText());
                            pst.executeUpdate();
                            JOptionPane.showMessageDialog(null,"Password changed successfully");
                        }
                        else {
                            JOptionPane.showMessageDialog(null,"New passwords doesn't match");
                        }
                    }else{
                        JOptionPane.showMessageDialog(null,"Invalid username or old password");
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Change.this.frame.setVisible(false);
                Login j=new Login();
                j.ted();
            }
        });
        frame = new JFrame("Change Password Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(500, 500));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
    }
    public static void ted() {
        new Change().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
