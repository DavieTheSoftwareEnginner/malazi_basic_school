package com.company.high;


import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Reg extends JFrame {
    private JPanel panel1;
    private JTextField number;
    private JComboBox Class;
    private JTextField reg;
    private JTextField mp;
    private JButton ADDButton;
    private JButton EXITButton;
    private JTextField surname;
    private JTextField adress;
    private JComboBox home;
    private JTextField name;
    private JRadioButton female;
    private JComboBox Gender;
    private JPanel Jdate;
    private JPanel Jadate;
    private JComboBox cat;
    private JFrame frame;

    JDateChooser dateChooser=new JDateChooser();
    JDateChooser smile=new JDateChooser();

    public Reg() {
        smile.setDateFormatString("dd/MM/yyyy");
        dateChooser.setDateFormatString("dd/MM/yyyy");
        Jadate.add(smile);
        Jdate.add(dateChooser);
        ADDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (reg.getText().isEmpty() || name.getText().isEmpty() || surname.getText().isEmpty()  || Class.getSelectedItem().toString().isEmpty() ||
                        adress.getText().isEmpty() || home.getSelectedItem().toString().isEmpty() || number.getText().isEmpty() || mp.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields are required");
                } else {
                    try {
                        String sql = "Select * from high where student_id=? or name=? and surname=?";
                        Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst1 = con1.prepareStatement(sql);
                        pst1.setString(1, reg.getText());
                        pst1.setString(2, name.getText());
                        pst1.setString(3, surname.getText());
                        ResultSet rs = pst1.executeQuery();
                        if(rs.next()){
                            JOptionPane.showMessageDialog(null,"Registration Number or Student Name Already Exist");
                        }
                        else{
                            SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy");
                            String dt=simpleDateFormat.format(dateChooser.getDate());
                            String adt=simpleDateFormat.format(smile.getDate());
                            String query = "Insert into high(category,student_id,name,surname,sex,BirthDate,class,admission,adress,Home,phone, Medical)" +
                                    "Values(?,?,?,?,?,?,?,?,?,?,?,?)";
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            PreparedStatement pst = con.prepareStatement(query);
                            pst.setString(1,cat.getSelectedItem().toString());
                            pst.setString(2, reg.getText());
                            pst.setString(3, name.getText());
                            pst.setString(4, surname.getText());
                            pst.setString(5, Gender.getSelectedItem().toString());
                            pst.setString(6, dt);
                            pst.setString(7, Class.getSelectedItem().toString());
                            pst.setString(8, adt);
                            pst.setString(9, adress.getText());
                            pst.setString(10, home.getSelectedItem().toString());
                            pst.setString(11, number.getText());
                            pst.setString(12, mp.getText());
                            pst.execute();
                            JOptionPane.showMessageDialog(null, "Registration Successful");
                        }
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Reg.this.frame.setVisible(false);
                HomePage j= new HomePage();
                j.ted();
            }
        });
        Class.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                if (cat.getSelectedItem().toString().equals("Boarder")) {
                    try {
                        String query = "Select * from high where class=? and Category=?";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setString(1, Class.getSelectedItem().toString());
                        pst.setString(2, cat.getSelectedItem().toString());
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            String query1 = "Select * from high where Student_ID IN(SELECT Max(student_id) from high where Class=? and Category=?)";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            PreparedStatement st = con1.prepareStatement(query1);
                            st.setString(1,Class.getSelectedItem().toString());
                            st.setString(2,cat.getSelectedItem().toString());
                            ResultSet rs1 = st.executeQuery();
                            if (rs1.next()) {
                                int r = rs1.getInt("Student_id");
                                int d = r + 1;
                                String f = String.valueOf(d);
                                reg.setText(f);
                            }
                        } else {
                            GregorianCalendar dat = new GregorianCalendar();
                            int year = dat.get(Calendar.YEAR);
                            String g = Class.getSelectedItem().toString();
                            String j = g + "1" + year + "001";
                            reg.setText(j);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }else{
                    try {
                        String query = "Select * from high where class=? and Category=?";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setString(1, Class.getSelectedItem().toString());
                        pst.setString(2, cat.getSelectedItem().toString());
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            String query1 = "Select * from high where Student_ID IN(SELECT Max(student_id) from high where Class=? and Category=?)";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            PreparedStatement st = con1.prepareStatement(query1);
                            st.setString(1,Class.getSelectedItem().toString());
                            st.setString(2,cat.getSelectedItem().toString());
                            ResultSet rs1 = st.executeQuery();
                            if (rs1.next()) {
                                int r = rs1.getInt("Student_id");
                                int d = r + 1;
                                String f = String.valueOf(d);
                                reg.setText(f);
                            }
                        } else {
                            GregorianCalendar dat = new GregorianCalendar();
                            int year = dat.get(Calendar.YEAR);
                            String g = Class.getSelectedItem().toString();
                            String j = g + "2" + year + "001";
                            reg.setText(j);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
        frame = new JFrame("Registration Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(600, 750));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
    }

    public static void ted() {
        new Reg().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }

}
