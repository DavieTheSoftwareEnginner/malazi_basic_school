package com.company.high;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Set extends JFrame{
    private JPanel panel1;
    private JTextField Boarder;
    private JTextField Commuter;
    private JButton doneButton;
    private JButton EXITButton;
    private JButton changeButton;
    private JFrame frame;

    public Set() {
        doneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (Boarder.getText().isEmpty()|| Commuter.getText().isEmpty()){
                    JOptionPane.showMessageDialog(null,"All fields are Required");
                }
                else {
                    try {
                        String sql = "Insert into High_Fees(Boarder,Commuter)Value(?,?)";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst = con.prepareStatement(sql);
                        pst.setString(1, Boarder.getText());
                        pst.setString(2, Commuter.getText());
                        pst.execute();
                        JOptionPane.showMessageDialog(null, "Fees set Successfully");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
        changeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (Boarder.getText().isEmpty() || Commuter.getText().isEmpty()){
                    JOptionPane.showMessageDialog(null,"All fields are required");
                }
                else {
                    try {
                        String sql = "Select * from High_fees";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(sql);
                        if (rs.next()) {
                            String r = rs.getString("Boarder");
                            String query = "Update high_fees set Boarder=?, Commuter=? where Boarder=?";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            PreparedStatement pst = con1.prepareStatement(query);
                            pst.setString(1, Boarder.getText());
                            pst.setString(2, Commuter.getText());
                            pst.setString(3,r);
                            pst.executeUpdate();
                            JOptionPane.showMessageDialog(null, "Changes made Successfully");
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Set.this.frame.setVisible(false);
                Accounts j=new Accounts();
                j.ted();
            }
        });
        frame = new JFrame("Set Fees Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(500, 500));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
    }
    public static void ted(){
        new Set().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
