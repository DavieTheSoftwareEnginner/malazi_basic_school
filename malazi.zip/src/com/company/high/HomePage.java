package com.company.high;


import com.company.UIAdditions;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePage extends JFrame{
    private JPanel panel1;
    private JButton REGISTERButton;
    private JButton EDITButton;
    private JButton EXITButton;
    private JButton VIEWButton;
    private JButton SEARCHANDDELETEButton;
    private JFrame frame;


    public HomePage() {
        this.dispose();
        REGISTERButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HomePage.this.frame.setVisible(false);
                Reg j= new Reg();
                j.ted();
            }
        });
        VIEWButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HomePage.this.frame.setVisible(false);
                View j=new View();
                j.ted();
            }
        });
        EDITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HomePage.this.frame.setVisible(false);
                Accounts j=new Accounts();
                j.ted();
            }
        });
        SEARCHANDDELETEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HomePage.this.frame.setVisible(false);
                Search j= new Search();
                j.ted();
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HomePage.this.frame.setVisible(false);
                com.company.Home j=new com.company.Home();
                j.ted();
            }
        });

        frame = new JFrame("Malazi High School Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(700, 500));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
    }


    public static void ted() {
        new HomePage().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
