package com.company.high;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.sql.*;

public class View extends JFrame{
    private JTable table1;
    private JPanel panel1;
    private JButton EXITButton;
    private JTextField Class;
    private JTextField a;
    private JButton VIEWButton;
    private JButton PRINTButton;
    private JScrollPane sor;
    private JPanel fat;
    private JTabbedPane far;
    private JFrame frame;
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public View() {
        this.dispose();
        createTable();
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                View.this.frame.setVisible(false);
                HomePage j=new HomePage();
                j.ted();
            }
        });
        VIEWButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String query = "Select * from high WHERE class=?";
                    con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst = con.prepareStatement(query);
                    pst.setString(1,Class.getText());
                    rs = pst.executeQuery();

                    while (rs.next()) {
                        String S = rs.getString("Student_ID");;
                        String N = rs.getString("Name");
                        String SU = rs.getString("Surname");;
                        String Sex = rs.getString("Sex");
                        String BD = rs.getString("BirthDate");
                        String C=rs.getString("class");
                        String A=rs.getString("admission");
                        String ad=rs.getString("adress");
                        String H= rs.getString("Home");
                        String P= rs.getString("Phone");
                        String M= rs.getString("Medical");

                        String[] tbData = {S, N, SU, Sex, BD,C,A,ad,H,P,M};
                        DefaultTableModel tb1Model = (DefaultTableModel) table1.getModel();
                        tb1Model.addRow(tbData);
                        int b=table1.getRowCount();
                        a.setText(String.valueOf(b));
                    }
                } catch (Exception ex){
                    JOptionPane.showMessageDialog(null, ex);
                }
            }
        });
        frame = new JFrame("View Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1250, 600));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
        PRINTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    table1.print();
                } catch (PrinterException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
    private void createTable(){
        table1.setModel(new DefaultTableModel (
                null,
                new String[]{"Registration Number", "Name", "Surname", "Gender", "BirthDate", "Class", "Admission Date", "Address",
                        "Home","Phone Number", "Medical Problems"}
        ));
    }


    public static void ted() {
        new View().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
