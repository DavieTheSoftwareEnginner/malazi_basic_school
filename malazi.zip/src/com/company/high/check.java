package com.company.high;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class check extends JFrame{
    private JPanel panel1;
    private JButton FEESPAYMENTButton;
    private JTextField bal;
    private JTextField sfees;
    private JTextField fees;
    private JTextField name;
    private JButton EXITButton;
    private JTextField reg;
    private JTextField rec;
    private JFrame frame;

    Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    public check() {
        reg.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                try {
                    String query="Select * from fees1 where name=?";
                    con= DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst= con.prepareStatement(query);
                    pst.setString(1,reg.getText());
                    rs=pst.executeQuery();
                    if (rs.next()){
                        String nam= rs.getString("Name");
                        String sur= rs.getString("Balance");
                        String fee=rs.getString("Fees_Paid");
                        String Sfee=rs.getString("School_Fees");
                        String Re=rs.getString("Receipt_Number");
                        name.setText(nam);
                        sfees.setText(Sfee);
                        fees.setText(fee);
                        bal.setText(sur);
                        rec.setText(Re);
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        frame = new JFrame("Check Balance Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(700, 500));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                check.this.frame.setVisible(false);
                Accounts j=new Accounts();
                j.ted();
            }
        });
    }


    public static void ted() {
        new check().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
