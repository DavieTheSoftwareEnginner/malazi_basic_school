package com.company.high;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Search extends JFrame{
    private JTextField number;
    private JTextField adate;
    private JTextField date;
    private JTextField Class;
    private JTextField name;
    private JTextField reg;
    private JTextField mp;
    private JButton DELETEButton;
    private JButton EXITButton;
    private JTextField surname;
    private JTextField adress;
    private JTextField home;
    private JPanel panel1;
    private JTextField gen;
    private JTextField search;
    private JButton EDITButton;
    private JTextField sur;
    private JFrame frame;

    Connection con=null;
    PreparedStatement pst=null;
    PreparedStatement pst1=null;
    PreparedStatement pst2=null;
    ResultSet rs=null;
    ResultSet rs1=null;

    public Search() {
        search.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                try {
                    String nel="Select * from high where Student_Id=?";
                    con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst1 = con.prepareStatement(nel);
                    pst1.setString(1, search.getText());
                    rs1 = pst1.executeQuery();
                    if (rs1.next()){
                        String S = rs1.getString("Student_ID");;
                        String N = rs1.getString("Name");
                        String SU = rs1.getString("Surname");;
                        String Sex = rs1.getString("Sex");
                        String BD = rs1.getString("BirthDate");
                        String C=rs1.getString("class");
                        String A=rs1.getString("admission");
                        String ad=rs1.getString("adress");
                        String H= rs1.getString("Home");
                        String P= rs1.getString("Phone");
                        String M= rs1.getString("Medical");

                        reg.setText(S);
                        name.setText(N);
                        surname.setText(SU);
                        gen.setText(Sex);
                        date.setText(BD);
                        Class.setText(C);
                        adate.setText(A);
                        adress.setText(ad);
                        home.setText(H);
                        number.setText(P);
                        mp.setText(M);
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        DELETEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    String mar= "SELECT * from high where Name=? and Surname=?";
                    String nel="Select * from high where Student_Id=?";
                    con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst = con.prepareStatement(mar);
                    pst.setString(1, search.getText());
                    pst1 = con.prepareStatement(nel);
                    pst1.setString(1, search.getText());
                    rs = pst.executeQuery();
                    rs1 = pst1.executeQuery();
                    if (rs.next()) {
                        String change = "DELETE from high where Name=?";
                        con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        pst = con.prepareStatement(change);
                        pst.setString(1, search.getText());
                        pst.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Record Deleted!!!!");
                    } else if(rs1.next()){
                        String change = "DELETE from high where Student_Id=?";
                        con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        pst = con.prepareStatement(change);
                        pst.setString(1, search.getText());
                        pst.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Record Deleted!!!!");
                    }else {
                        JOptionPane.showMessageDialog(null, "Name or Registration Number doesn't Exist", "Change of Details Denied",
                                +JOptionPane.ERROR_MESSAGE);
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        EDITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String query = "Update high set student_id=?, name=?,surname=?,sex=?,BirthDate=?,class=?,admission=?,adress=?," +
                            "Home=?,phone=?, Medical=? where BirthDate=?";
                    con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst2 = con.prepareStatement(query);
                    pst2.setString(1, reg.getText());
                    pst2.setString(2, name.getText());
                    pst2.setString(3, surname.getText());
                    pst2.setString(4, gen.getText());
                    pst2.setString(5, date.getText());
                    pst2.setString(6, Class.getText());
                    pst2.setString(7, adate.getText());
                    pst2.setString(8, adress.getText());
                    pst2.setString(9, home.getText());
                    pst2.setString(10, number.getText());
                    pst2.setString(11, mp.getText());
                    pst2.setString(12,date.getText());
                    pst2.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Edited Successful");
                } catch(Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        });
        frame = new JFrame("Search Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(600, 800));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Search.this.frame.setVisible(false);
                HomePage j=new HomePage();
                j.ted();
            }
        });
        KeyAdapter listener = new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                try {
                    String mar= "SELECT * from high where Name=? and Surname=?";
                    con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst = con.prepareStatement(mar);
                    pst.setString(1, search.getText());
                    pst.setString(2,sur.getText());
                    rs = pst.executeQuery();
                    if (rs.next()) {
                        String S = rs.getString("Student_ID");;
                        String N = rs.getString("Name");
                        String SU = rs.getString("Surname");;
                        String Sex = rs.getString("Sex");
                        String BD = rs.getString("BirthDate");
                        String C=rs.getString("class");
                        String A=rs.getString("admission");
                        String ad=rs.getString("adress");
                        String H= rs.getString("Home");
                        String P= rs.getString("Phone");
                        String M= rs.getString("Medical");

                        reg.setText(S);
                        name.setText(N);
                        surname.setText(SU);
                        gen.setText(Sex);
                        date.setText(BD);
                        Class.setText(C);
                        adate.setText(A);
                        adress.setText(ad);
                        home.setText(H);
                        number.setText(P);
                        mp.setText(M);
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        };
        search.addKeyListener(listener);
        sur.addKeyListener(listener);
    }


    public static void ted() {
        new Search().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}