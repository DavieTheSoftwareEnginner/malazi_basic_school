package com.company;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.RoundRectangle2D;

public class UIAdditions {
    public static void setRoundedBorder(JButton button, int radius, Color borderColor) {
        // Create a rounded border with specified border color
        Border roundedBorder = new Border() {
            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(borderColor);
                g2.draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radius, radius));
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(radius - 35, radius - 10, radius - 35, radius);
            }

            @Override
            public boolean isBorderOpaque() {
                return true;
            }
        };

        // Set the rounded border to the JButton without changing size
        button.setBorder(BorderFactory.createCompoundBorder(
                roundedBorder,
                BorderFactory.createEmptyBorder(5, 10, 5, 10) // No additional padding
        ));
    }


    public static void setPlaceholder(JTextField textField, String placeholder) {
        textField.setText(placeholder);
        textField.setForeground(Color.GRAY);

        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setText(placeholder);
                    textField.setForeground(Color.GRAY);
                }
            }
        });
    }

    public static Border createCurvedBorder(int radius, Color color) {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color, 2),
                BorderFactory.createEmptyBorder(radius, radius, radius, radius)
        );
    }

    public static void setRoundedBorder1(JPanel panel, int radius, Color borderColor) {
        // Create a rounded border with specified border color
        Border roundedBorder = new Border() {
            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(borderColor);
                g2.draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radius, radius));
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(radius + 1, radius + 1, radius + 2, radius);
            }

            @Override
            public boolean isBorderOpaque() {
                return true;
            }
        };

        // Set the rounded border to the JButton without changing size
        panel.setBorder(BorderFactory.createCompoundBorder(
                roundedBorder,
                BorderFactory.createEmptyBorder(0, 0, 0, 0) // No additional padding
        ));
    }

    public static void setRoundedBorder2(JTextField panel, int radius, Color borderColor) {
        // Create a rounded border with specified border color
        Border roundedBorder = new Border() {
            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(borderColor);
                g2.draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radius, radius));
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(radius + 1, radius + 1, radius + 2, radius);
            }

            @Override
            public boolean isBorderOpaque() {
                return true;
            }
        };

        // Set the rounded border to the JButton without changing size
        panel.setBorder(BorderFactory.createCompoundBorder(
                roundedBorder,
                BorderFactory.createEmptyBorder(0, 0, 0, 0) // No additional padding
        ));
    }

    public static void setRoundedBorder3(JComboBox panel, int radius, Color borderColor) {
        // Create a rounded border with specified border color
        Border roundedBorder = new Border() {
            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(borderColor);
                g2.draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radius, radius));
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(radius + 1, radius + 1, radius + 2, radius);
            }

            @Override
            public boolean isBorderOpaque() {
                return true;
            }
        };

        // Set the rounded border to the JButton without changing size
        panel.setBorder(BorderFactory.createCompoundBorder(
                roundedBorder,
                BorderFactory.createEmptyBorder(0, 0, 0, 0) // No additional padding
        ));
    }

}
