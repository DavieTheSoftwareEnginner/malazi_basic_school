package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;

public class Second extends JFrame{
    private JPanel panel1;
    private JButton FEESPAYMENTButton;
    private JTextField bal;
    private JTextField sfees;
    private JTextField fees;
    private JTextField name;
    private JButton DONEButton;
    private JButton EXITButton;
    private JTextField reg;
    private JTextField rec;
    private JTextField cat;
    private JTextField textField1;
    private JFrame frame;

    Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    public Second() {
        reg.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                try {
                    String query="Select * from fees where student_id=?";
                    con= DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst= con.prepareStatement(query);
                    pst.setString(1,reg.getText());
                    rs=pst.executeQuery();
                    if (rs.next()){
                        String nam= rs.getString("Name");
                        String sur= rs.getString("Balance");
                        name.setText(nam);
                        sfees.setText(sur);
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        frame = new JFrame("Second Installment Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(700, 500));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
        DONEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String query = "Select * from fees where student_id=?";
                    con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst = con.prepareStatement(query);
                    pst.setString(1, reg.getText());
                    rs = pst.executeQuery();
                    if (rs.next()) {
                        int balance = Integer.valueOf(sfees.getText()) - Integer.valueOf(fees.getText());
                        bal.setText(String.valueOf(balance));
                        String sql = "Update fees set Fees_Paid=Fees_Paid+?, Balance=?, receipt_number=? where Student_Id=?";
                        con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        pst = con.prepareStatement(sql);
                        pst.setString(4, reg.getText());
                        pst.setString(1, fees.getText());
                        pst.setString(2, bal.getText());
                        pst.setString(3,rec.getText());
                        pst.execute();
                        JOptionPane.showMessageDialog(null, "Fees paid Successfully");
                    } else {
                        JOptionPane.showMessageDialog(null, "Registration Number unavailable");
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Second.this.frame.setVisible(false);
                Accounts j=new Accounts();
                j.ted();
            }
        });
        name.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                try {
                    String query="Select * from fees where Name=?";
                    con= DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst= con.prepareStatement(query);
                    pst.setString(1,name.getText());
                    rs=pst.executeQuery();
                    if (rs.next()){
                        String nam= rs.getString("Student_ID");
                        String sur= rs.getString("Balance");
                        String ca=rs.getString("Category");
                        reg.setText(nam);
                        sfees.setText(sur);
                        cat.setText(ca);
                       }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        cat.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if (cat.getText().equals("Boarder")) {
                    try {
                        String query = "Select * from fees where Category=?";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setString(1, cat.getText());
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            String query1 = "Select * from fees where Receipt_Number IN(SELECT Max(Receipt_Number) from fees where category='Boarder')";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            Statement st = con1.createStatement();
                            ResultSet rs1 = st.executeQuery(query1);
                            if (rs1.next()) {
                                int r = rs1.getInt("Receipt_Number");
                                int d = r + 1;
                                String f = String.valueOf(d);
                                rec.setText(f);
                            }
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                } else if (cat.getText().equals("Commuter")) {
                    try {
                        String query = "Select * from fees where Category=?";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setString(1, cat.getText());
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            String query1 = "Select * from fees where Receipt_Number IN(SELECT Max(Receipt_Number) from fees where category='commuter')";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            Statement st = con1.createStatement();
                            ResultSet rs1 = st.executeQuery(query1);
                            if (rs1.next()) {
                                int r = rs1.getInt("Receipt_Number");
                                int d = r + 1;
                                String f = String.valueOf(d);
                                rec.setText(f);
                            }
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                } else {
                    try {
                        String query = "Select * from fees where Category=?";
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setString(1, cat.getText());
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            String query1 = "Select * from fees where Receipt_Number IN(SELECT Max(Receipt_Number) from fees where category='Pre_School')";
                            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                            Statement st = con1.createStatement();
                            ResultSet rs1 = st.executeQuery(query1);
                            if (rs1.next()) {
                                int r = rs1.getInt("Receipt_Number");
                                int d = r + 1;
                                String f = String.valueOf(d);
                                rec.setText(f);
                            }
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
            }
        });
    }


    public static void ted() {
        new Second().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
