package com.company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;
import java.sql.*;

public class vfees extends JFrame{
    private JButton VIEWSTUDENTSWITHBALANCESButton;
    private JTextField Class;
    private JTable table1;
    private JPanel panel1;
    private JButton EXITButton;
    private JButton PRINTButton;
    private JFrame frame;

    Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    public vfees() {
        createTable();
        Class.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                try {
                    String query = "Select * from Registration WHERE class=?";
                    String sql= "Select * from fees where balance>0";
                    con = DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst = con.prepareStatement(query);
                    pst.setString(1,Class.getText());
                    rs = pst.executeQuery();
                    Statement pst1=con.createStatement();
                    ResultSet rs1=pst1.executeQuery(sql);
                    while (rs.next() && rs1.next()) {
                        String S = rs1.getString("Student_ID");;
                        String N = rs1.getString("Name");
                        String SU = rs1.getString("Fees_Paid");;
                        String Sex = rs1.getString("School_Fees");
                        String BD = rs1.getString("Balance");
                        String rec=rs1.getString("Receipt_Number");
                        String C=rs.getString("class");

                        String[] tbData = {S, N, SU, Sex, BD, rec,C};
                        DefaultTableModel tb1Model = (DefaultTableModel) table1.getModel();
                        tb1Model.addRow(tbData);
                    }
                } catch (Exception ex){
                    JOptionPane.showMessageDialog(null, ex);
                }
            }
        });
        frame = new JFrame("View Students With Balances Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(700, 500));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vfees.this.frame.setVisible(false);
                Accounts j=new Accounts();
                j.ted();
            }
        });
        PRINTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    table1.print();
                }catch (PrinterException ex){
                    ex.printStackTrace();
                }
            }
        });
    }


    public static void ted() {
        new vfees().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }

    private void createTable(){
        table1.setModel(new DefaultTableModel(
                null,
                new String[]{"Registration Number", "Name", "Fees Paid", "School Fees", "Balance", "Receipt Number", "Class"}
        ));
    }
}
