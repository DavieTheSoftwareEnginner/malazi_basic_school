package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame{
    private JPanel panel1;
    private JButton MALAZIBASICSCHOOLButton;
    private JButton MALAZIHIGHSCHOOLButton;
    private JFrame frame;

    public Home() {
        MALAZIBASICSCHOOLButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Home.this.frame.setVisible(false);
                com.company.HomePage j=new com.company.HomePage();
                j.ted();
            }
        });
        MALAZIHIGHSCHOOLButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Home.this.frame.setVisible(false);
                HomePage j=new HomePage();
                j.ted();
            }
        });

        frame = new JFrame("Home Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(840, 500));
        frame.setResizable(true);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
    }
    public static void ted(){
        new Home().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
