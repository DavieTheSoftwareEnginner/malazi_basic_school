package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Accounts extends JFrame{
    private JPanel panel1;
    private JButton PAYButton;
    private JButton CHECKBALANCEButton;
    private JButton EXITButton;
    private JButton STUDENTSWITHBALANCESButton;
    private JButton FIRSTINSTALLMENTButton;
    private JButton SECONDINSTALLMENTButton;
    private JButton SETFEESButton;
    private JFrame frame;

    public Accounts() {
        FIRSTINSTALLMENTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Accounts.this.frame.setVisible(false);
                Pay j=new Pay();
                j.ted();
            }
        });
        SECONDINSTALLMENTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Accounts.this.frame.setVisible(false);
                Second j=new Second();
                j.ted();
            }
        });
        STUDENTSWITHBALANCESButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Accounts.this.frame.setVisible(false);
               vfees j= new vfees();
                j.ted();
            }
        });
        CHECKBALANCEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Accounts.this.frame.setVisible(false);
               check j= new check();
                j.ted();
            }
        });
        EXITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Accounts.this.frame.setVisible(false);
               HomePage j= new HomePage();
                j.ted();
            }
        });
        frame = new JFrame("Accounts Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(700, 500));
        frame.setResizable(false);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
        SETFEESButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Accounts.this.frame.setVisible(false);
                Set j=new Set();
                j.ted();
            }
        });
    }

    public static void ted() {
        new Accounts().frame.setVisible(true);
    }

    public static void main(String[] args) {
        ted();
    }
}
