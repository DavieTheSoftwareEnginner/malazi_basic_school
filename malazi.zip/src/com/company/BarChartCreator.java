package com.company;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class BarChartCreator {


    public static CategoryDataset createDataset() {
        databases db = new databases();
        int currentYear = LocalDate.now().getYear();

        // Subtract 2 to get the year two years ago
        int one = currentYear - 1;
        int two = currentYear - 2;

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Add sample data
        dataset.addValue(db.getStats(String.valueOf(two), "1"), String.valueOf(two), "Standard 1");
        dataset.addValue(db.getStats(String.valueOf(one), "1"), String.valueOf(one), "Standard 1");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "1"), String.valueOf(currentYear), "Standard 1");

        dataset.addValue(db.getStats(String.valueOf(two), "2"), String.valueOf(two), "Standard 2");
        dataset.addValue(db.getStats(String.valueOf(one), "2"), String.valueOf(one), "Standard 2");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "2"), String.valueOf(currentYear), "Standard 2");

        dataset.addValue(db.getStats(String.valueOf(two), "3"), String.valueOf(two), "Standard 3");
        dataset.addValue(db.getStats(String.valueOf(one), "3"), String.valueOf(one), "Standard 3");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "3"), String.valueOf(currentYear), "Standard 3");

        dataset.addValue(db.getStats(String.valueOf(two), "4"), String.valueOf(two), "Standard 4");
        dataset.addValue(db.getStats(String.valueOf(one), "4"), String.valueOf(one), "Standard 4");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "4"), String.valueOf(currentYear), "Standard 4");

        dataset.addValue(db.getStats(String.valueOf(two), "5"), String.valueOf(two), "Standard 5");
        dataset.addValue(db.getStats(String.valueOf(one), "5"), String.valueOf(one), "Standard 5");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "5"), String.valueOf(currentYear), "Standard 5");

        dataset.addValue(db.getStats(String.valueOf(two), "6"), String.valueOf(two), "Standard 6");
        dataset.addValue(db.getStats(String.valueOf(one), "6"), String.valueOf(one), "Standard 6");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "6"), String.valueOf(currentYear), "Standard 6");

        dataset.addValue(db.getStats(String.valueOf(two), "7"), String.valueOf(two), "Standard 7");
        dataset.addValue(db.getStats(String.valueOf(one), "7"), String.valueOf(one), "Standard 7");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "7"), String.valueOf(currentYear), "Standard 7");

        dataset.addValue(db.getStats(String.valueOf(two), "8"), String.valueOf(two), "Standard 8");
        dataset.addValue(db.getStats(String.valueOf(one), "8"), String.valueOf(one), "Standard 8");
        dataset.addValue(db.getStats(String.valueOf(currentYear), "8"), String.valueOf(currentYear), "Standard 8");

        return dataset;
    }

    public static JFreeChart createChart(CategoryDataset dataset) {
        return ChartFactory.createBarChart(
                "Class Enrollment Yearly",
                "Category",
                "Value",
                dataset
        );
    }

    public static JPanel createChartPanel(JFreeChart chart) {
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(450, 450));
        return chartPanel;
    }
}
