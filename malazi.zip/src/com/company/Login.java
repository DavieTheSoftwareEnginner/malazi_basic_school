package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Login extends JFrame{
    private JPanel panel1;
    private JButton LOGINButton;
    private JButton CREATENEWACCOUNTButton;
    private JTextField Username;
    private JPasswordField pass;
    private JLabel CHANGEPASSWORDLabel;
    private JButton LOGOUTButton;
    private JFrame frame;

    PreparedStatement pst=null;
    Connection con=null;
    ResultSet rs=null;
    UIAdditions additions= new UIAdditions();

    public Login() {
        LOGINButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String sql="Select * from Login where UserName=? and Password=?";
                    con= DriverManager.getConnection("jdbc:mysql://localhost/david", "root", "");
                    pst=con.prepareStatement(sql);
                    pst.setString(1,Username.getText());
                    pst.setString(2,pass.getText());
                    rs=pst.executeQuery();
                    if (rs.next()){
                        JOptionPane.showMessageDialog(null,"Login Successfully");
                        Login.this.frame.setVisible(false);
                        Home j=new Home();
                        j.ted();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "Incorrect Username or Password");
                    }
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex);
                }
            }
        });
        CREATENEWACCOUNTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login.this.frame.setVisible(false);
                create j=new create();
                j.ted();
            }
        });
//        CHANGEPASSWORDLabel.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                Login.this.frame.setVisible(false);
//                Change j=new Change();
//                j.ted();
//            }
//        });

        CHANGEPASSWORDLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
//                super.mouseClicked(e);
                Login.this.frame.setVisible(false);
                Change j=new Change();
                j.ted();
            }
        });

        pass.setBorder(null);
        Username.setBorder(null);
        additions.setRoundedBorder(CREATENEWACCOUNTButton, 40, Color.WHITE);
        CREATENEWACCOUNTButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        LOGINButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        CHANGEPASSWORDLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        additions.setPlaceholder(Username, "Username");
        additions.setPlaceholder(pass, "Username");
        frame = new JFrame("Login Page");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(840, 500));
        frame.setResizable(true);

        frame.add(panel1);

        frame.pack();
        frame.setLocationRelativeTo(null);
    }
    public static void ted() {
        new Login().frame.setVisible(true);
    }


    public static void main(String[] args) {
        ted();
    }


}
