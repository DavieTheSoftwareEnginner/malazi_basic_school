-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2022 at 02:30 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `david`
--

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `Category` varchar(20) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Fees_Paid` varchar(20) NOT NULL,
  `School_Fees` varchar(10) NOT NULL,
  `Balance` varchar(11) NOT NULL,
  `Receipt_Number` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`Category`, `student_id`, `Name`, `Fees_Paid`, `School_Fees`, `Balance`, `Receipt_Number`) VALUES
('Boarder', '812022001', 'david Gondwe', '80000', '70000', '0', 2),
('Commuter', '822022001', 'Uwemi Gondwe', '10000', '15000', '5000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fees1`
--

CREATE TABLE `fees1` (
  `Category` varchar(20) NOT NULL,
  `student_id` varchar(30) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Fees_Paid` varchar(30) NOT NULL,
  `School_Fees` varchar(15) NOT NULL,
  `Balance` varchar(20) NOT NULL,
  `Receipt_Number` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees1`
--

INSERT INTO `fees1` (`Category`, `student_id`, `Name`, `Fees_Paid`, `School_Fees`, `Balance`, `Receipt_Number`) VALUES
('Boarder', '412022001', 'Uwemi Gondwe', '110000', '110000', '0', 2);

-- --------------------------------------------------------

--
-- Table structure for table `high`
--

CREATE TABLE `high` (
  `Category` varchar(20) NOT NULL,
  `student_id` varchar(40) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `BirthDate` varchar(30) NOT NULL,
  `class` varchar(20) NOT NULL,
  `Admission` varchar(30) NOT NULL,
  `Adress` varchar(30) NOT NULL,
  `Home` varchar(30) NOT NULL,
  `Phone` varchar(30) NOT NULL,
  `Medical` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `high`
--

INSERT INTO `high` (`Category`, `student_id`, `Name`, `surname`, `sex`, `BirthDate`, `class`, `Admission`, `Adress`, `Home`, `Phone`, `Medical`) VALUES
('Boarder', '412022001', 'Uwemi', 'Gondwe', 'Male', '31/10/2004', '4', '11/02/2022', 'Bolero', 'Rumphi', '0888381031', 'None'),
('Boarder', '312022001', 'Gomi', 'Gondwe', 'Male', '18/02/2005', '3', '13/02/2022', 'Bolero', 'Rumphi', '0888381031', 'None'),
('Commuter', '422022001', 'Uwe ', 'Gondwe', 'Male', '31/10/2003', '4', '13/02/2022', 'Bolero', 'Rumphi', '0887280262', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `high_fees`
--

CREATE TABLE `high_fees` (
  `Boarder` int(11) NOT NULL,
  `Commuter` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `high_fees`
--

INSERT INTO `high_fees` (`Boarder`, `Commuter`) VALUES
(110000, 25000);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`UserName`, `Password`, `Email`) VALUES
('teddie', 'sadd', 'sad');

-- --------------------------------------------------------

--
-- Table structure for table `malazi fees`
--

CREATE TABLE `malazi fees` (
  `Boarder` int(20) NOT NULL,
  `Commuter` int(20) NOT NULL,
  `Pre-School` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `malazi fees`
--

INSERT INTO `malazi fees` (`Boarder`, `Commuter`, `Pre-School`) VALUES
(70000, 15000, 10000),
(70000, 25000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `Category` varchar(30) NOT NULL,
  `student_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `BirthDate` varchar(30) NOT NULL,
  `class` varchar(30) NOT NULL,
  `admission` varchar(30) NOT NULL,
  `Adress` varchar(30) NOT NULL,
  `Home` varchar(30) NOT NULL,
  `Phone` varchar(30) NOT NULL,
  `Code` varchar(30) NOT NULL,
  `Medical` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Category`, `student_id`, `name`, `surname`, `sex`, `BirthDate`, `class`, `admission`, `Adress`, `Home`, `Phone`, `Code`, `Medical`) VALUES
('Boarder', 812022001, 'David', 'Gondwe', 'Male', '31/10/2004', '8', '09/02/2022', 'Bolero', 'Rumphi', '0888381031', '123456789', 'None'),
('Commuter', 822022001, 'Uwemi', 'Gondwe', 'Male', '16/02/2007', '8', '14/02/2022', 'Rumphi Boma', 'Lilongwe', '0994140050', '111222', 'none'),
('Commuter', 812022001, 'David', 'Gondwe', 'Male', '31/10/2004', '8', '09/02/2022', 'Bolero', 'Rumphi', '0888381031', '123456789', 'None'),
('Boarder', 812022002, 'Uwemi F', 'Gondwe', 'Male', '12/04/2022', '8', '13/04/2022', 'hriighigf', 'Chitipa', '0494155', '123456', 'None');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
